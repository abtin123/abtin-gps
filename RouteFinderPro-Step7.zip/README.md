# مسیر یاب حرفه‌ای (RouteFinderPro)

اسکلت کامل یک اپلیکیشن اندروید ناوبری/مسیریابی با Kotlin، Google Maps SDK،
Places API (جست‌وجوی مقصد) و Directions API (محاسبه و رسم مسیر روی نقشه).

## امکانات این اسکلت
- نمایش نقشه و موقعیت فعلی کاربر (FusedLocationProviderClient)
- جست‌وجوی مقصد با Google Places Autocomplete
- دریافت مسیر از Directions API و رسم آن به‌صورت Polyline روی نقشه
- نمایش فاصله و زمان تخمینی سفر
- دکمهٔ «موقعیت من» و «پاک‌کردن مسیر»
- مدیریت مجوز موقعیت مکانی (Runtime Permission)
- معماری تمیز: جدا بودن لایهٔ شبکه (Retrofit) از UI

## راه‌اندازی (خیلی مهم)

### ۱. گرفتن کلید Google Maps API
۱. به [Google Cloud Console](https://console.cloud.google.com/) بروید و یک پروژه بسازید.
۲. این APIها را فعال کنید:
   - Maps SDK for Android
   - Places API
   - Directions API
۳. یک API Key بسازید و محدودیت آن را روی «Android apps» و `applicationId` این پروژه
   (`com.example.routefinderpro`) تنظیم کنید.

### ۲. قرار دادن کلید در پروژه
فایل `local.properties.example` را کپی و به‌نام `local.properties` (کنار
`settings.gradle.kts`) ذخیره کنید، سپس:

```
MAPS_API_KEY=کلید_واقعی_شما
```

کلید به‌صورت خودکار هم در `AndroidManifest.xml` (برای Maps SDK) و هم در
`BuildConfig.MAPS_API_KEY` (برای Places/Directions در کد Kotlin) تزریق می‌شود.
هرگز کلید واقعی را داخل کد یا گیت‌هاب commit نکنید.

### ۳. باز کردن در Android Studio
1. Android Studio → Open → پوشهٔ `RouteFinderPro` را انتخاب کنید.
2. صبر کنید Gradle Sync تمام شود (اگر پیام «Gradle wrapper missing» دید،
   اجازه دهید Android Studio آن را خودش دانلود/بازسازی کند، یا از منوی
   File > Sync Project with Gradle Files استفاده کنید).
3. یک دستگاه/شبیه‌ساز با **Google Play Services** انتخاب و Run بزنید.

## نکات حرفه‌ای برای ادامهٔ توسعه
- **امنیت کلید**: در نسخهٔ Production بهتر است فراخوانی Directions API از یک
  سرور واسط (Backend) انجام شود تا کلید هرگز داخل اپ کلاینت قرار نگیرد.
- **حالت‌های سفر**: پارامتر `mode` در `DirectionsApiService` را می‌توانید
  به `walking`, `bicycling`, `transit` تغییر دهید یا در UI قابل انتخاب کنید.
- **مسیرهای چندگانه**: Directions API می‌تواند چند مسیر جایگزین برگرداند
  (`alternatives=true`)؛ می‌توانید همه را نمایش دهید و کاربر یکی را انتخاب کند.
- **ناوبری گام‌به‌گام (Turn-by-turn)**: برای این سطح حرفه‌ای‌تر معمولاً از
  `steps` داخل هر `leg` استفاده و دستورات را پخش صوتی می‌کنند (نیازمند
  TextToSpeech + به‌روزرسانی مداوم موقعیت).
- **آفلاین‌بودن**: اگر نیاز به کارکرد بدون اینترنت دارید، جایگزین‌هایی مثل
  OSMDroid + GraphHopper/Valhalla (خودمیزبان) مناسب‌ترند؛ بگویید تا نسخهٔ
  آفلاین را هم برایتان بسازم.

## ساختار پروژه
```
RouteFinderPro/
 ├── app/
 │   ├── build.gradle.kts
 │   └── src/main/
 │       ├── AndroidManifest.xml
 │       ├── java/com/example/routefinderpro/
 │       │   ├── MainActivity.kt
 │       │   ├── RouteFinderApp.kt
 │       │   └── data/
 │       │       ├── DirectionsApiService.kt
 │       │       ├── RetrofitClient.kt
 │       │       ├── RouteRepository.kt
 │       │       └── model/DirectionsResponse.kt
 │       └── res/ (layout, values, drawable, mipmap, xml)
 ├── build.gradle.kts
 ├── settings.gradle.kts
 ├── gradle.properties
 └── local.properties.example
```
