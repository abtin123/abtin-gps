# Keep Directions API model classes (Gson reflection)
-keep class com.example.routefinderpro.data.model.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
