package com.example.routefinderpro

import android.app.Application
import com.google.android.libraries.places.api.Places

class RouteFinderApp : Application() {

    override fun onCreate() {
        super.onCreate()
        if (!Places.isInitialized() && BuildConfig.MAPS_API_KEY.isNotBlank()) {
            Places.initialize(applicationContext, BuildConfig.MAPS_API_KEY)
        }
    }
}
