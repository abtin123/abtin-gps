package com.example.routefinderpro

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.routefinderpro.data.RouteOutcome
import com.example.routefinderpro.data.RouteRepository
import com.example.routefinderpro.databinding.ActivityMainBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMainBinding
    private lateinit var map: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var routeRepository: RouteRepository

    private var currentLocation: LatLng? = null
    private var destinationLocation: LatLng? = null
    private var destinationMarker: com.google.android.gms.maps.model.Marker? = null
    private var routePolyline: com.google.android.gms.maps.model.Polyline? = null

    private val locationPermissionRequest =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                enableMyLocation()
            } else {
                Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_LONG).show()
            }
        }

    private val placeAutocompleteLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val place = Autocomplete.getPlaceFromIntent(result.data!!)
                onDestinationSelected(place)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        routeRepository = RouteRepository(BuildConfig.MAPS_API_KEY)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (!Places.isInitialized() && BuildConfig.MAPS_API_KEY.isNotBlank()) {
            Places.initialize(applicationContext, BuildConfig.MAPS_API_KEY)
        }

        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.searchCard.setOnClickListener { openPlaceAutocomplete() }
        binding.fabMyLocation.setOnClickListener { moveToCurrentLocation() }
        binding.btnClearRoute.setOnClickListener { clearRoute() }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isZoomControlsEnabled = true
        map.uiSettings.isMapToolbarEnabled = false
        checkLocationPermissionAndEnable()
    }

    private fun checkLocationPermissionAndEnable() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted) {
            enableMyLocation()
        } else {
            locationPermissionRequest.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    @Suppress("MissingPermission")
    private fun enableMyLocation() {
        map.isMyLocationEnabled = true
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                currentLocation = LatLng(location.latitude, location.longitude)
                map.moveCamera(
                    CameraUpdateFactory.newLatLngZoom(currentLocation!!, 15f)
                )
            }
        }
    }

    @Suppress("MissingPermission")
    private fun moveToCurrentLocation() {
        val loc = currentLocation
        if (loc != null) {
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 16f))
        } else {
            checkLocationPermissionAndEnable()
        }
    }

    private fun openPlaceAutocomplete() {
        val fields = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
            .build(this)
        placeAutocompleteLauncher.launch(intent)
    }

    private fun onDestinationSelected(place: Place) {
        val latLng = place.latLng ?: return
        destinationLocation = latLng
        binding.destinationText.text = place.name ?: getString(R.string.search_hint)

        destinationMarker?.remove()
        destinationMarker = map.addMarker(
            MarkerOptions().position(latLng).title(place.name)
        )
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))

        val origin = currentLocation
        if (origin == null) {
            Toast.makeText(this, getString(R.string.permission_rationale), Toast.LENGTH_LONG).show()
            checkLocationPermissionAndEnable()
            return
        }
        fetchAndDrawRoute(origin, latLng)
    }

    private fun fetchAndDrawRoute(origin: LatLng, destination: LatLng) {
        binding.routeProgress.visibility = View.VISIBLE
        binding.routeInfoText.text = getString(R.string.loading_route)
        binding.btnClearRoute.visibility = View.GONE

        lifecycleScope.launch {
            when (val outcome = routeRepository.fetchRoute(origin, destination)) {
                is RouteOutcome.Success -> {
                    drawRoute(outcome.result.points)
                    binding.routeInfoText.text = getString(
                        R.string.distance_duration_format,
                        outcome.result.distanceText,
                        outcome.result.durationText
                    )
                    binding.btnClearRoute.visibility = View.VISIBLE
                }
                is RouteOutcome.NoRoute -> {
                    binding.routeInfoText.text = getString(R.string.error_no_route)
                }
                is RouteOutcome.Error -> {
                    binding.routeInfoText.text = getString(R.string.error_network)
                }
            }
            binding.routeProgress.visibility = View.GONE
        }
    }

    private fun drawRoute(points: List<LatLng>) {
        routePolyline?.remove()
        routePolyline = map.addPolyline(
            PolylineOptions()
                .addAll(points)
                .width(12f)
                .color(ContextCompat.getColor(this, R.color.route_line))
                .geodesic(true)
        )
    }

    private fun clearRoute() {
        routePolyline?.remove()
        routePolyline = null
        destinationMarker?.remove()
        destinationMarker = null
        destinationLocation = null
        binding.destinationText.text = getString(R.string.search_hint)
        binding.routeInfoText.text = getString(R.string.route_placeholder)
        binding.btnClearRoute.visibility = View.GONE
    }
}
