package com.example.routefinderpro.data

import com.example.routefinderpro.data.model.DirectionsResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface DirectionsApiService {

    @GET("maps/api/directions/json")
    suspend fun getDirections(
        @Query("origin") origin: String,
        @Query("destination") destination: String,
        @Query("mode") mode: String = "driving",
        @Query("language") language: String = "fa",
        @Query("key") apiKey: String
    ): Response<DirectionsResponse>
}
