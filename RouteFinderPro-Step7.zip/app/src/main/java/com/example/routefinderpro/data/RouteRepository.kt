package com.example.routefinderpro.data

import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.PolyUtil

/**
 * Result of a successful route calculation, ready for the UI layer.
 */
data class RouteResult(
    val points: List<LatLng>,
    val distanceText: String,
    val durationText: String
)

sealed class RouteOutcome {
    data class Success(val result: RouteResult) : RouteOutcome()
    object NoRoute : RouteOutcome()
    data class Error(val message: String) : RouteOutcome()
}

class RouteRepository(private val apiKey: String) {

    suspend fun fetchRoute(origin: LatLng, destination: LatLng): RouteOutcome {
        return try {
            val response = RetrofitClient.directionsApi.getDirections(
                origin = "${origin.latitude},${origin.longitude}",
                destination = "${destination.latitude},${destination.longitude}",
                apiKey = apiKey
            )

            if (!response.isSuccessful) {
                return RouteOutcome.Error("HTTP ${response.code()}")
            }

            val body = response.body() ?: return RouteOutcome.NoRoute
            if (body.status != "OK" || body.routes.isEmpty()) {
                return RouteOutcome.NoRoute
            }

            val route = body.routes.first()
            val leg = route.legs.firstOrNull() ?: return RouteOutcome.NoRoute
            val decodedPoints = PolyUtil.decode(route.overviewPolyline.points)

            RouteOutcome.Success(
                RouteResult(
                    points = decodedPoints,
                    distanceText = leg.distance.text,
                    durationText = leg.duration.text
                )
            )
        } catch (e: Exception) {
            RouteOutcome.Error(e.message ?: "Unknown error")
        }
    }
}
