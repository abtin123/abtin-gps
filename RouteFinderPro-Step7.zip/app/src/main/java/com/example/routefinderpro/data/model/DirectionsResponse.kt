package com.example.routefinderpro.data.model

import com.google.gson.annotations.SerializedName

/**
 * Minimal model matching the fields we actually use from the
 * Google Directions API JSON response.
 * https://developers.google.com/maps/documentation/directions/get-directions
 */
data class DirectionsResponse(
    @SerializedName("routes") val routes: List<Route>,
    @SerializedName("status") val status: String
)

data class Route(
    @SerializedName("legs") val legs: List<Leg>,
    @SerializedName("overview_polyline") val overviewPolyline: OverviewPolyline
)

data class Leg(
    @SerializedName("distance") val distance: TextValue,
    @SerializedName("duration") val duration: TextValue,
    @SerializedName("start_address") val startAddress: String,
    @SerializedName("end_address") val endAddress: String
)

data class TextValue(
    @SerializedName("text") val text: String,
    @SerializedName("value") val value: Int
)

data class OverviewPolyline(
    @SerializedName("points") val points: String
)
