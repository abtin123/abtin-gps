package com.routefinder.ui.topbar
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable fun TopNavigationBar(){Row(Modifier.fillMaxWidth().padding(12.dp).background(Color(0xB3202328),RoundedCornerShape(24.dp)).padding(16.dp),verticalAlignment=Alignment.CenterVertically){NavigationArrow();Spacer(Modifier.width(12.dp));NavigationInfoCard();Spacer(Modifier.weight(1f));SpeedLimitView();Spacer(Modifier.width(8.dp));CloseButton()}}