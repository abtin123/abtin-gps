package com.routefinder.ui.components
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
@Composable
fun GlassButton(onClick:()->Unit,modifier:Modifier=Modifier,content:@Composable()->Unit){
 FilledTonalButton(onClick=onClick,modifier=modifier){content()}
}