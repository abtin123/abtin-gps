package com.routefinder.ui.bottombar
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable
fun BottomNavigationBar(){
Row(Modifier.fillMaxWidth().padding(16.dp).background(Color(0xB3202328),RoundedCornerShape(24.dp)).padding(12.dp),horizontalArrangement=Arrangement.SpaceEvenly){
BottomButton(AppIcons.Search)
BottomButton(AppIcons.Route)
BottomButton(AppIcons.Home)
BottomButton(AppIcons.Save)
BottomButton(AppIcons.Settings)
}}