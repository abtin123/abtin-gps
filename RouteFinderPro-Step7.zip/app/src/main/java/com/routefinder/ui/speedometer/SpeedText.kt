package com.routefinder.ui.speedometer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Box
@Composable
fun SpeedText(speed:Int){
Box(contentAlignment=Alignment.Center){
Text(speed.toString())
}
}