package com.routefinder.ui.topbar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
@Composable fun NavigationArrow(){Text("⬆")}