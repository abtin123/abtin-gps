package com.routefinder.ui.bottombar
object AppIcons{
const val Search="🔍"
const val Home="🏠"
const val Route="🧭"
const val Save="⭐"
const val Settings="⚙"
}