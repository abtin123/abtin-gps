package com.routefinder.ui.theme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp
val AppShapes=Shapes(extraSmall=RoundedCornerShape(8.dp),small=RoundedCornerShape(14.dp),medium=RoundedCornerShape(22.dp),large=RoundedCornerShape(28.dp),extraLarge=RoundedCornerShape(34.dp))