package com.routefinder.ui.speedometer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
@Composable
fun SpeedArc(progress:Float){
Canvas(Modifier.fillMaxSize()){
drawArc(
brush=Brush.sweepGradient(listOf(Color.Green,Color.Yellow,Color.Red)),
startAngle=135f,
sweepAngle=270f*progress,
useCenter=false,
style=Stroke(width=28f,cap=StrokeCap.Round)
)
}}