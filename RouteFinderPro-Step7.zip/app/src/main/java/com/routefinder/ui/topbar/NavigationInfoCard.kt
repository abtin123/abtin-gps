package com.routefinder.ui.topbar
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
@Composable fun NavigationInfoCard(){Column{Text("500 m");Text("Next turn")}}