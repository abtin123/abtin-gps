package com.routefinder.ui.components
import androidx.compose.ui.Modifier
fun Modifier.neonGlow()=this
