package com.routefinder.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
private val DarkScheme=darkColorScheme(primary=AppColors.Orange,secondary=AppColors.Blue,background=AppColors.Background,surface=AppColors.Glass)
@Composable fun RouteFinderTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=DarkScheme,typography=AppTypography,shapes=AppShapes,content=content)}