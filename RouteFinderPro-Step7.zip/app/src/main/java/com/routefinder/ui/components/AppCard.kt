package com.routefinder.ui.components
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable
fun AppCard(content:@Composable ColumnScope.()->Unit){
 GlassPanel{Column(Modifier.padding(16.dp),content=content)}
}