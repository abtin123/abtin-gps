package com.routefinder.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.routefinder.ui.theme.AppColors
import com.routefinder.ui.topbar.TopNavigationBar
@Composable
fun NavigationScreen(){
 Box(Modifier.fillMaxSize().background(AppColors.Background)){
  TopNavigationBar()
 }
}