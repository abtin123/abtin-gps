package com.routefinder.ui.theme

import androidx.compose.ui.graphics.Color
object AppColors{val Background=Color(0xFF101317)
val Glass=Color(0xB3202328)
val GlassLight=Color(0xD62B3037)
val Orange=Color(0xFFFF8C00)
val Yellow=Color(0xFFFFC107)
val Green=Color(0xFF2ECC71)
val Blue=Color(0xFF35B8FF)
val Red=Color(0xFFFF5252)
val White=Color(0xFFF5F5F5)
val Gray=Color(0xFFBFC7D1)
val Border=Color(0x30FFFFFF)
val Glow=Color(0x5535B8FF)}