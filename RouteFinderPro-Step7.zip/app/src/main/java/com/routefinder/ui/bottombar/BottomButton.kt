package com.routefinder.ui.bottombar
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
@Composable
fun BottomButton(label:String,onClick:()->Unit={}){FilledTonalButton(onClick=onClick){Text(label)}}