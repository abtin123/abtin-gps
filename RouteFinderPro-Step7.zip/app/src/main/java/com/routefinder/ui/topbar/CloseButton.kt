package com.routefinder.ui.topbar
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
@Composable fun CloseButton(onClick:()->Unit={}){TextButton(onClick=onClick){Text("✕")}}