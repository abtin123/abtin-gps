package com.routefinder.ui.theme
import androidx.compose.ui.unit.dp
object Dimens{val Radius=22.dp;val GlassBorder=1.dp;val PanelPadding=16.dp;val Shadow=20.dp;val TopBarHeight=90.dp;val BottomBarHeight=88.dp;val ButtonSize=56.dp}