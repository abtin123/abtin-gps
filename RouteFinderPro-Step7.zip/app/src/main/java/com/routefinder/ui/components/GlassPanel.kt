package com.routefinder.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable
fun GlassPanel(modifier:Modifier=Modifier,content:@Composable BoxScope.()->Unit){
 Box(modifier.clip(RoundedCornerShape(22.dp))
 .background(Color(0xB3202328))
 .border(1.dp,Color.White.copy(.12f),RoundedCornerShape(22.dp))){content()}
}