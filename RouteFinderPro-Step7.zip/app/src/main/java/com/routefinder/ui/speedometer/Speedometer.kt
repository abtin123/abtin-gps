package com.routefinder.ui.speedometer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable
fun Speedometer(speed:Int){
Box(Modifier.size(170.dp),contentAlignment=Alignment.Center){
SpeedArc(speed/180f)
SpeedText(speed)
}
}